<?php

$arPSCorrespondence = [
	'ORDER_ID' => [
		'NAME'  => GetMessage('MM_ORDER_ID'),
		'DESCR' => '',
		'VALUE' => 'ID',
		'TYPE'  => 'ORDER',
	],
];