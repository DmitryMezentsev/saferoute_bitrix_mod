<?php

$arModuleVersion = [
	'VERSION'      => '2.2.2',
	'VERSION_DATE' => '2020-08-24 00:00:00',
];