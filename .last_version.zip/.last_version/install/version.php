<?php

$arModuleVersion = [
	'VERSION'      => '2.0.2',
	'VERSION_DATE' => '2020-06-09 00:00:00',
];