<?php

$arModuleVersion = [
    'VERSION'      => '2.3.4',
    'VERSION_DATE' => '2021-05-08 00:00:00',
];
