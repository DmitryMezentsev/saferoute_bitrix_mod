<?php

$arModuleVersion = [
    'VERSION'      => '2.3.5',
    'VERSION_DATE' => '2021-05-12 00:00:00',
];
