<?php

$arModuleVersion = [
	'VERSION'      => '2.2.3',
	'VERSION_DATE' => '2020-08-31 00:00:00',
];