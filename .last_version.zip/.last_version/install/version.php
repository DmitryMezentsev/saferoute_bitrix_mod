<?php

$arModuleVersion = [
	'VERSION'      => '2.2.4',
	'VERSION_DATE' => '2020-09-15 00:00:00',
];