<?php

$arModuleVersion = [
    'VERSION'      => '2.3.2',
    'VERSION_DATE' => '2020-10-05 00:00:00',
];
