<?php

$arModuleVersion = [
	'VERSION'      => '2.2.5',
	'VERSION_DATE' => '2020-09-22 00:00:00',
];