<?php

$arModuleVersion = [
	'VERSION'      => '2.0.3',
	'VERSION_DATE' => '2020-06-11 00:00:00',
];