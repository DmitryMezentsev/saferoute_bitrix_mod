<?php

$arModuleVersion = [
	'VERSION'      => '2.2.0',
	'VERSION_DATE' => '2020-08-07 00:00:00',
];