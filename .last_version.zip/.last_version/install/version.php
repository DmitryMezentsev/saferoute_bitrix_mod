<?php

$arModuleVersion = [
	'VERSION'      => '2.0.0',
	'VERSION_DATE' => '2020-05-29 00:00:00',
];