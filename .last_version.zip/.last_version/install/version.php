<?php

$arModuleVersion = [
    'VERSION'      => '2.3.1',
    'VERSION_DATE' => '2020-09-29 00:00:00',
];
