<?php

$arModuleVersion = [
    'VERSION'      => '2.3.3',
    'VERSION_DATE' => '2020-12-03 00:00:00',
];
