<?php

$arModuleVersion = [
    'VERSION'      => '2.3.0',
    'VERSION_DATE' => '2020-09-26 00:00:00',
];
