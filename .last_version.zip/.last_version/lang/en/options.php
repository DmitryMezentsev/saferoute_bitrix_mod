<?php

$MESS['SAFEROUTE_WIDGET_TAB_SETTINGS']           = 'Settings';
$MESS['SAFEROUTE_WIDGET_TOKEN']                  = 'Token';
$MESS['SAFEROUTE_WIDGET_SHOP_ID']                = 'Shop ID';
$MESS['SAFEROUTE_WIDGET_DISABLE_MULTI_REQUESTS'] = 'Disable parallel loading of delivery methods<br>(use if the widget loads delivery too slowly)';

$MESS['SAFEROUTE_WIDGET_SETTINGS_COMMON']                = 'Common';
$MESS['SAFEROUTE_WIDGET_ORD_PROPS_CODES_IND']            = 'Order props codes (individual)';
$MESS['SAFEROUTE_WIDGET_ORD_PROPS_CODES_LGL']            = 'Order props codes (legal entity)';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_FIO']              = 'Fullname';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_LOCATION']         = 'Location';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_PHONE']            = 'Phone';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_EMAIL']            = 'Email';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_CITY']             = 'City';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_ADDRESS']          = 'Address';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_ZIP']              = 'ZIP Code';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_TIN']              = 'TIN';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_COMPANY_NAME']     = 'Company name';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_DELIVERY_ADDRESS'] = 'Delivery address';
$MESS['SAFEROUTE_WIDGET_ORD_PROP_CODE_CONTACT_PERSON']   = 'Contact person';

$MESS['SAFEROUTE_WIDGET_PROD_PROPS_CODES']               = 'Product props codes';
$MESS['SAFEROUTE_WIDGET_PROD_PROP_CODE_VENDOR_CODE']     = 'Vendor code';