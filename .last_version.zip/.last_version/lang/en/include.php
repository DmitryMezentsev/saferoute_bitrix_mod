<?php

$MESS['SAFEROUTE_WIDGET_CURL_ERROR'] = 'SafeRoute widget requires PHP cURL';