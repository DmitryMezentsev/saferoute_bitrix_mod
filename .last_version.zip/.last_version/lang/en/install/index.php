<?php

$MESS['SAFEROUTE_WIDGET_MOD_NAME']                    = 'Cart Widget SafeRoute';
$MESS['SAFEROUTE_WIDGET_MOD_DESCRIPTION']             = 'Embeds SafeRoute widget in checkout, and adds API to the CMS for interaction with SafeRoute';
$MESS['SAFEROUTE_PARTNER_NAME']                       = 'SafeRoute';
$MESS['SAFEROUTE_WIDGET_PARTNER_URI']                 = 'https://saferoute.ru';
$MESS['SAFEROUTE_WIDGET_ERROR_VERSION']               = 'Your version 1C-Bitrix unsupported the module. Please, update your 1C-Bitrix.';
$MESS['SAFEROUTE_WIDGET_INSTALL_TITLE']               = 'Install SafeRoute Module';
$MESS['SAFEROUTE_WIDGET_UNINSTALL_TITLE']             = 'Uninstall SafeRoute Module';
$MESS['SAFEROUTE_WIDGET_PAY_SYSTEM_DESC']             = 'Payment via SafeRoute widget';
$MESS['SAFEROUTE_WIDGET_DELIVERY_SERV_TITLE']         = 'SafeRoute';
$MESS['SAFEROUTE_WIDGET_COURIER_DELIVERY_SERV_TITLE'] = 'SafeRoute (Courier)';
$MESS['SAFEROUTE_WIDGET_PICKUP_DELIVERY_SERV_TITLE']  = 'SafeRoute (Pickup)';
$MESS['SAFEROUTE_WIDGET_DELIVERY_SERV_DESC']          = 'Delivery using SafeRoute aggregator';
$MESS['SAFEROUTE_WIDGET_COURIER_DELIVERY_SERV_DESC']  = 'Courier delivery using SafeRoute aggregator';
$MESS['SAFEROUTE_WIDGET_PICKUP_DELIVERY_SERV_DESC']   = 'Pickup delivery using SafeRoute aggregator';