<?php

$MESS['SAFEROUTE_WIDGET_SETTINGS_PROMPT'] = 'Do not forget to set SafeRoute account token and shop ID in module settings.';